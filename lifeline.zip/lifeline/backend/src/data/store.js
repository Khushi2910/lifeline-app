const volunteers = new Map();
const emergencies = [];

module.exports = {
  volunteers,
  emergencies
};

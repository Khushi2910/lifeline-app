const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");
const env = require("./config/env");
const volunteerRoutes = require("./routes/volunteers");
const emergencyRoutes = require("./routes/emergencies");
const { initializeSocket } = require("./socket");

const app = express();
app.use(cors({ origin: env.clientOrigin }));
app.use(express.json());

app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "lifeline-backend"
  });
});

app.use("/api/volunteers", volunteerRoutes);
app.use("/api/emergencies", emergencyRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: env.clientOrigin,
    methods: ["GET", "POST"]
  }
});

initializeSocket(io);

server.listen(env.port, () => {
  console.log(`Lifeline backend listening on port ${env.port}`);
});

const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { volunteers } = require("../data/store");

const router = express.Router();

router.get("/", (req, res) => {
  res.json({
    data: Array.from(volunteers.values())
  });
});

router.post("/register", (req, res) => {
  const { id, name, phone, skills, available, location } = req.body;

  if (
    !name ||
    !Array.isArray(skills) ||
    location?.lat === undefined ||
    location?.lng === undefined
  ) {
    return res.status(400).json({
      error: "name, skills array, and location(lat,lng) are required"
    });
  }

  const volunteerId = id || uuidv4();
  const volunteer = {
    id: volunteerId,
    name,
    phone: phone || "",
    skills: skills.map((skill) => String(skill).trim().toLowerCase()),
    available: available !== false,
    location: {
      lat: Number(location.lat),
      lng: Number(location.lng)
    },
    updatedAt: new Date().toISOString()
  };

  volunteers.set(volunteerId, volunteer);
  return res.status(201).json({ data: volunteer });
});

router.post("/availability", (req, res) => {
  const { volunteerId, available, location } = req.body;
  const volunteer = volunteers.get(volunteerId);

  if (!volunteer) {
    return res.status(404).json({ error: "Volunteer not found" });
  }

  volunteer.available = Boolean(available);
  if (location?.lat !== undefined && location?.lng !== undefined) {
    volunteer.location = {
      lat: Number(location.lat),
      lng: Number(location.lng)
    };
  }
  volunteer.updatedAt = new Date().toISOString();

  volunteers.set(volunteerId, volunteer);
  return res.json({ data: volunteer });
});

module.exports = router;

const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { emergencies, volunteers } = require("../data/store");
const { rankVolunteersForEmergency } = require("../services/matching");
const {
  emitEmergencyToVolunteer,
  emitEmergencyBroadcast
} = require("../socket");

const router = express.Router();

router.get("/", (req, res) => {
  res.json({ data: emergencies });
});

router.post("/", (req, res) => {
  const { reporterName, type, notes, location } = req.body;
  if (!type || location?.lat === undefined || location?.lng === undefined) {
    return res.status(400).json({
      error: "type and location(lat,lng) are required"
    });
  }

  const emergency = {
    id: uuidv4(),
    reporterName: reporterName || "Unknown",
    type: String(type).trim().toLowerCase(),
    notes: notes || "",
    location: {
      lat: Number(location.lat),
      lng: Number(location.lng)
    },
    createdAt: new Date().toISOString()
  };

  const rankedMatches = rankVolunteersForEmergency(
    emergency,
    Array.from(volunteers.values())
  );

  const topMatches = rankedMatches.slice(0, 5).map((entry) => ({
    volunteerId: entry.volunteer.id,
    name: entry.volunteer.name,
    distanceKm: entry.distanceKm,
    skills: entry.volunteer.skills,
    score: entry.score
  }));

  const emergencyWithMatches = {
    ...emergency,
    suggestedResponders: topMatches
  };
  emergencies.unshift(emergencyWithMatches);

  topMatches.forEach((match) => {
    emitEmergencyToVolunteer(match.volunteerId, {
      emergency: emergencyWithMatches,
      match
    });
  });

  emitEmergencyBroadcast(emergencyWithMatches);

  return res.status(201).json({
    data: emergencyWithMatches
  });
});

module.exports = router;

const { haversineDistanceKm } = require("../utils/distance");

const emergencySkillWeights = {
  medical: {
    doctor: 40,
    nurse: 30,
    first_aid: 30
  },
  heart_issue: {
    doctor: 45,
    first_aid: 40,
    nurse: 20
  },
  accident: {
    first_aid: 40,
    paramedic: 35,
    doctor: 25
  },
  mental_distress: {
    counselor: 40,
    psychologist: 40,
    first_aid: 20
  },
  general_help: {
    rescuer: 30,
    first_aid: 30,
    driver: 20
  }
};

function getSkillScore(type, skills) {
  const weightMap = emergencySkillWeights[type] || emergencySkillWeights.general_help;
  return skills.reduce((sum, skill) => sum + (weightMap[skill] || 0), 0);
}

function getDistanceScore(distanceKm) {
  const maxRadiusKm = 25;
  const normalized = Math.max(0, maxRadiusKm - distanceKm) / maxRadiusKm;
  return normalized * 60;
}

function getHeartPriorityBoost(type, skills) {
  if (type !== "heart_issue") {
    return 0;
  }
  const hasPrioritySkill = skills.includes("doctor") || skills.includes("first_aid");
  return hasPrioritySkill ? 50 : 0;
}

function rankVolunteersForEmergency(emergency, volunteers) {
  return volunteers
    .filter((volunteer) => volunteer.available)
    .map((volunteer) => {
      const distanceKm = haversineDistanceKm(emergency.location, volunteer.location);
      const distanceScore = getDistanceScore(distanceKm);
      const skillScore = Math.min(40, getSkillScore(emergency.type, volunteer.skills));
      const heartBoost = getHeartPriorityBoost(emergency.type, volunteer.skills);
      const totalScore = distanceScore + skillScore + heartBoost;

      return {
        volunteer,
        distanceKm: Number(distanceKm.toFixed(2)),
        score: Number(totalScore.toFixed(2))
      };
    })
    .filter((entry) => entry.distanceKm <= 25)
    .sort((a, b) => b.score - a.score);
}

module.exports = {
  rankVolunteersForEmergency
};

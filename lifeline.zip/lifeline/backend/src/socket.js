let ioRef = null;
const volunteerSocketMap = new Map();

function initializeSocket(io) {
  ioRef = io;

  io.on("connection", (socket) => {
    socket.on("volunteer:join", ({ volunteerId }) => {
      if (volunteerId) {
        volunteerSocketMap.set(volunteerId, socket.id);
      }
    });

    socket.on("disconnect", () => {
      for (const [volunteerId, socketId] of volunteerSocketMap.entries()) {
        if (socketId === socket.id) {
          volunteerSocketMap.delete(volunteerId);
        }
      }
    });
  });
}

function emitEmergencyToVolunteer(volunteerId, payload) {
  if (!ioRef) {
    return;
  }
  const socketId = volunteerSocketMap.get(volunteerId);
  if (socketId) {
    ioRef.to(socketId).emit("emergency:alert", payload);
  }
}

function emitEmergencyBroadcast(payload) {
  if (!ioRef) {
    return;
  }
  ioRef.emit("emergency:new", payload);
}

module.exports = {
  initializeSocket,
  emitEmergencyToVolunteer,
  emitEmergencyBroadcast
};

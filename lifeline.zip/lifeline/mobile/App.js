import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";
import HomeScreen from "./src/screens/HomeScreen";
import RequestHelpScreen from "./src/screens/RequestHelpScreen";
import VolunteerRegisterScreen from "./src/screens/VolunteerRegisterScreen";
import VolunteerDashboardScreen from "./src/screens/VolunteerDashboardScreen";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: "Lifeline" }} />
        <Stack.Screen name="RequestHelp" component={RequestHelpScreen} options={{ title: "SOS" }} />
        <Stack.Screen
          name="VolunteerRegister"
          component={VolunteerRegisterScreen}
          options={{ title: "Volunteer Sign Up" }}
        />
        <Stack.Screen
          name="VolunteerDashboard"
          component={VolunteerDashboardScreen}
          options={{ title: "Volunteer Alerts" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

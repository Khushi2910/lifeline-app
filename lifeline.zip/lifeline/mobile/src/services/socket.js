import { io } from "socket.io-client";
import { API_BASE_URL } from "../config/api";

let socketRef;

export function getSocket() {
  if (!socketRef) {
    socketRef = io(API_BASE_URL, {
      transports: ["websocket"]
    });
  }
  return socketRef;
}

import React, { useState } from "react";
import {
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import * as Location from "expo-location";
import { request } from "../config/api";

const emergencyTypes = [
  { id: "medical", label: "Medical" },
  { id: "heart_issue", label: "Heart Issue" },
  { id: "accident", label: "Accident" },
  { id: "mental_distress", label: "Mental Distress" },
  { id: "general_help", label: "General Help" }
];

export default function RequestHelpScreen() {
  const [reporterName, setReporterName] = useState("");
  const [notes, setNotes] = useState("");
  const [type, setType] = useState("general_help");
  const [loading, setLoading] = useState(false);
  const [responseInfo, setResponseInfo] = useState(null);

  const triggerEmergency = async () => {
    setLoading(true);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        throw new Error("Location permission is required to send SOS.");
      }

      const current = await Location.getCurrentPositionAsync({});
      const payload = {
        reporterName: reporterName || "Anonymous",
        type,
        notes,
        location: {
          lat: current.coords.latitude,
          lng: current.coords.longitude
        }
      };

      const response = await request("/api/emergencies", {
        method: "POST",
        body: JSON.stringify(payload)
      });

      const responders = response.data.suggestedResponders || [];
      setResponseInfo({
        emergencyId: response.data.id,
        responders
      });
      Alert.alert("SOS Sent", `Notified ${responders.length} nearby volunteer(s).`);
    } catch (error) {
      Alert.alert("Could not send SOS", error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Request Emergency Help</Text>

      <TextInput
        value={reporterName}
        onChangeText={setReporterName}
        placeholder="Your name (optional)"
        style={styles.input}
      />

      <Text style={styles.label}>Emergency Type</Text>
      <View style={styles.typeWrap}>
        {emergencyTypes.map((item) => (
          <TouchableOpacity
            key={item.id}
            onPress={() => setType(item.id)}
            style={[styles.typeButton, type === item.id && styles.typeButtonActive]}
          >
            <Text style={[styles.typeText, type === item.id && styles.typeTextActive]}>
              {item.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput
        value={notes}
        onChangeText={setNotes}
        placeholder="Extra notes (optional)"
        style={[styles.input, styles.notes]}
        multiline
      />

      <TouchableOpacity
        style={[styles.sosButton, loading && styles.disabled]}
        onPress={triggerEmergency}
        disabled={loading}
      >
        <Text style={styles.sosText}>{loading ? "Sending..." : "SEND SOS"}</Text>
      </TouchableOpacity>

      {responseInfo && (
        <View style={styles.result}>
          <Text style={styles.resultTitle}>Top Responders</Text>
          {responseInfo.responders.map((responder) => (
            <Text key={responder.volunteerId} style={styles.resultItem}>
              {responder.name} - {responder.distanceKm} km - score {responder.score}
            </Text>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#f8fafc"
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 14
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    marginTop: 8,
    marginBottom: 8
  },
  input: {
    backgroundColor: "#fff",
    borderColor: "#d1d5db",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12
  },
  notes: {
    marginTop: 10,
    minHeight: 80,
    textAlignVertical: "top"
  },
  typeWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8
  },
  typeButton: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 20
  },
  typeButtonActive: {
    backgroundColor: "#fee2e2",
    borderColor: "#ef4444"
  },
  typeText: {
    color: "#334155",
    fontWeight: "600"
  },
  typeTextActive: {
    color: "#b91c1c"
  },
  sosButton: {
    marginTop: 16,
    backgroundColor: "#dc2626",
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 16
  },
  sosText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "800"
  },
  disabled: {
    opacity: 0.7
  },
  result: {
    marginTop: 18,
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 12
  },
  resultTitle: {
    fontWeight: "700",
    marginBottom: 6
  },
  resultItem: {
    marginTop: 4,
    color: "#1e293b"
  }
});

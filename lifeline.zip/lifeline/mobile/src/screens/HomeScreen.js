import React from "react";
import { SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

export default function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Lifeline</Text>
      <Text style={styles.subtitle}>Hyperlocal Emergency Help</Text>

      <TouchableOpacity
        style={styles.sosButton}
        onPress={() => navigation.navigate("RequestHelp")}
      >
        <Text style={styles.sosText}>SOS</Text>
      </TouchableOpacity>

      <View style={styles.actions}>
        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => navigation.navigate("VolunteerRegister")}
        >
          <Text style={styles.secondaryText}>I Want To Volunteer</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => navigation.navigate("VolunteerDashboard")}
        >
          <Text style={styles.secondaryText}>Volunteer Dashboard</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24
  },
  title: {
    fontSize: 42,
    fontWeight: "800",
    color: "#111827"
  },
  subtitle: {
    marginTop: 6,
    marginBottom: 42,
    color: "#374151",
    fontSize: 16
  },
  sosButton: {
    width: 220,
    height: 220,
    borderRadius: 120,
    backgroundColor: "#dc2626",
    alignItems: "center",
    justifyContent: "center",
    elevation: 6
  },
  sosText: {
    color: "#ffffff",
    fontSize: 48,
    fontWeight: "900"
  },
  actions: {
    width: "100%",
    marginTop: 40,
    gap: 12
  },
  secondaryButton: {
    backgroundColor: "#1f2937",
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: "center"
  },
  secondaryText: {
    color: "#ffffff",
    fontSize: 15,
    fontWeight: "700"
  }
});

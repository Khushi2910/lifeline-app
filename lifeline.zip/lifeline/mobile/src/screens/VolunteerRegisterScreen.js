import React, { useState } from "react";
import {
  Alert,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import * as Location from "expo-location";
import { request } from "../config/api";

const availableSkills = [
  "doctor",
  "nurse",
  "first_aid",
  "paramedic",
  "driver",
  "rescuer",
  "counselor",
  "psychologist"
];

export default function VolunteerRegisterScreen() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [skills, setSkills] = useState(["first_aid"]);
  const [loading, setLoading] = useState(false);
  const [registeredId, setRegisteredId] = useState("");

  const toggleSkill = (skill) => {
    setSkills((prev) =>
      prev.includes(skill) ? prev.filter((item) => item !== skill) : [...prev, skill]
    );
  };

  const registerVolunteer = async () => {
    if (!name.trim()) {
      Alert.alert("Name required", "Please enter your name.");
      return;
    }
    if (skills.length === 0) {
      Alert.alert("Skills required", "Select at least one skill.");
      return;
    }

    setLoading(true);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        throw new Error("Location permission is required for volunteer matching.");
      }
      const current = await Location.getCurrentPositionAsync({});
      const payload = {
        name,
        phone,
        skills,
        available: true,
        location: {
          lat: current.coords.latitude,
          lng: current.coords.longitude
        }
      };
      const response = await request("/api/volunteers/register", {
        method: "POST",
        body: JSON.stringify(payload)
      });

      setRegisteredId(response.data.id);
      Alert.alert(
        "Registered",
        `Volunteer ID: ${response.data.id}\nUse this ID in dashboard login.`
      );
    } catch (error) {
      Alert.alert("Registration failed", error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Volunteer Registration</Text>

      <TextInput
        value={name}
        onChangeText={setName}
        placeholder="Full name"
        style={styles.input}
      />
      <TextInput
        value={phone}
        onChangeText={setPhone}
        placeholder="Phone"
        style={styles.input}
      />

      <Text style={styles.label}>Skills</Text>
      <View style={styles.skillWrap}>
        {availableSkills.map((skill) => {
          const active = skills.includes(skill);
          return (
            <TouchableOpacity
              key={skill}
              style={[styles.skill, active && styles.skillActive]}
              onPress={() => toggleSkill(skill)}
            >
              <Text style={[styles.skillText, active && styles.skillTextActive]}>{skill}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <TouchableOpacity
        style={[styles.button, loading && styles.disabled]}
        onPress={registerVolunteer}
        disabled={loading}
      >
        <Text style={styles.buttonText}>{loading ? "Registering..." : "Register Volunteer"}</Text>
      </TouchableOpacity>

      {registeredId ? <Text style={styles.idText}>Saved Volunteer ID: {registeredId}</Text> : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
    padding: 16
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 12
  },
  label: {
    fontWeight: "600",
    marginBottom: 8
  },
  input: {
    backgroundColor: "#fff",
    borderColor: "#d1d5db",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 10
  },
  skillWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 14
  },
  skill: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: "#fff"
  },
  skillActive: {
    backgroundColor: "#dcfce7",
    borderColor: "#22c55e"
  },
  skillText: {
    color: "#1e293b"
  },
  skillTextActive: {
    color: "#166534",
    fontWeight: "600"
  },
  button: {
    backgroundColor: "#111827",
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: "center"
  },
  buttonText: {
    color: "#fff",
    fontWeight: "700"
  },
  disabled: {
    opacity: 0.7
  },
  idText: {
    marginTop: 12,
    color: "#0369a1",
    fontWeight: "600"
  }
});

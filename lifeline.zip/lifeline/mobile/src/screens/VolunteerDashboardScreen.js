import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import * as Location from "expo-location";
import { getSocket } from "../services/socket";
import { request } from "../config/api";

export default function VolunteerDashboardScreen() {
  const [volunteerId, setVolunteerId] = useState("");
  const [connectedId, setConnectedId] = useState("");
  const [alerts, setAlerts] = useState([]);
  const [isAvailable, setIsAvailable] = useState(true);
  const socket = useMemo(() => getSocket(), []);

  useEffect(() => {
    const onAlert = (payload) => {
      setAlerts((prev) => [payload, ...prev]);
    };

    socket.on("emergency:alert", onAlert);
    return () => {
      socket.off("emergency:alert", onAlert);
    };
  }, [socket]);

  const connectAsVolunteer = () => {
    if (!volunteerId.trim()) {
      Alert.alert("Volunteer ID required", "Enter your volunteer ID.");
      return;
    }

    socket.emit("volunteer:join", { volunteerId: volunteerId.trim() });
    setConnectedId(volunteerId.trim());
    Alert.alert("Connected", "Realtime emergency alerts are now enabled.");
  };

  const updateAvailability = async () => {
    if (!connectedId) {
      Alert.alert("Not connected", "Connect with volunteer ID first.");
      return;
    }

    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        throw new Error("Location permission is required to update availability.");
      }
      const current = await Location.getCurrentPositionAsync({});
      const next = !isAvailable;

      await request("/api/volunteers/availability", {
        method: "POST",
        body: JSON.stringify({
          volunteerId: connectedId,
          available: next,
          location: {
            lat: current.coords.latitude,
            lng: current.coords.longitude
          }
        })
      });

      setIsAvailable(next);
      Alert.alert("Updated", `You are now ${next ? "available" : "unavailable"}.`);
    } catch (error) {
      Alert.alert("Update failed", error.message);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Volunteer Dashboard</Text>
      <TextInput
        style={styles.input}
        value={volunteerId}
        onChangeText={setVolunteerId}
        placeholder="Enter volunteer ID"
      />
      <TouchableOpacity style={styles.button} onPress={connectAsVolunteer}>
        <Text style={styles.buttonText}>Connect</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.secondaryButton} onPress={updateAvailability}>
        <Text style={styles.secondaryText}>
          Toggle Availability (Current: {isAvailable ? "Available" : "Unavailable"})
        </Text>
      </TouchableOpacity>

      <Text style={styles.heading}>Incoming Emergency Alerts</Text>
      <ScrollView style={styles.list}>
        {alerts.length === 0 ? (
          <Text style={styles.empty}>No alerts yet.</Text>
        ) : (
          alerts.map((alert, index) => (
            <View key={`${alert.emergency.id}-${index}`} style={styles.card}>
              <Text style={styles.cardTitle}>{alert.emergency.type.toUpperCase()}</Text>
              <Text>Reporter: {alert.emergency.reporterName}</Text>
              <Text>Distance: {alert.match.distanceKm} km</Text>
              <Text>Priority score: {alert.match.score}</Text>
              <Text>Notes: {alert.emergency.notes || "No notes"}</Text>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
    padding: 16
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 10
  },
  heading: {
    marginTop: 14,
    marginBottom: 8,
    fontWeight: "700",
    fontSize: 16
  },
  input: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10
  },
  button: {
    marginTop: 10,
    backgroundColor: "#111827",
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 12
  },
  buttonText: {
    color: "#fff",
    fontWeight: "700"
  },
  secondaryButton: {
    marginTop: 10,
    borderColor: "#111827",
    borderWidth: 1,
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 12
  },
  secondaryText: {
    color: "#111827",
    fontWeight: "600"
  },
  list: {
    marginTop: 8
  },
  empty: {
    color: "#64748b",
    marginTop: 8
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 12,
    marginBottom: 8
  },
  cardTitle: {
    fontWeight: "700",
    marginBottom: 4
  }
});
